function [A,b,n] = Konfiguration3()

A = [ 2 4 2; 0 2 1; 1 1 4];
b = [6; 1; 3];
n = 3;

endfunction
