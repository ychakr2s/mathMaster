function [] = Gauss()

[A,b,n] = Konfiguration3;
M = ErwKoeffMatrix(A,b,n);
M = Elimination(M,n);
x = Rueckwaertseinsetzen(M,n);
disp(x)

endfunction
