function [A,b,n] = Konfiguration2()

A = [ 0 2 1; 2 4 2; 1 1 4];
b = [1; 6; 3];
n = 3;

endfunction
