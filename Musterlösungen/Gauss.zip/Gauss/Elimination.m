function [A] = Elimination(A,n)

	for k = 1 : n-1
		for i = k+1 : n
			l(i,k) = A(i,k)/A(k,k);
			for j = k : n+1
				A(i,j)= A(i,j)-(l(i,k)*A(k,j));
			end
		end
	end

endfunction
