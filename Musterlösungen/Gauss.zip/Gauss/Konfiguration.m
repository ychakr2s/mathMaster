function [A,b,n] = Konfiguration()

A = [ 1 1 1; 2 3 7; 1 3 -2];
b = [3; 0; 17];
n = 3;

endfunction

