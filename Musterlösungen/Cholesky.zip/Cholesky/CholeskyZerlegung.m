function [L] = CholeskyZerlegung(A,n)

        L = zeros(n,n);

	for j = 1 : n

            % Diagonaleintraege
            summe1 = 0;
            for k = 1 : j-1
                summe1 = summe1 + (L(j,k))^2;
            end
            L(j,j) = sqrt(A(j,j) - summe1);
            
            % Nicht-Diagonaleintraege
            for i = j+1 : n
                summe2 = 0;
                for k = 1 : j-1
                    summe2 = summe2 + L(i,k) * L(j,k);
                end
                L(i,j) = (A(i,j) - summe2) / L(j,j);
            end

        end

endfunction
