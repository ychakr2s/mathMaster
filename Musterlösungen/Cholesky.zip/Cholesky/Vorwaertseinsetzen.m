function [y] = Vorwaertseinsetzen(L2,n)

y(1)= L2(1, n+1)/L2(1,1);

for i = 2 : n
	summe = 0; 
	for j = 1 : i-1
		summe = summe + L2(i,j)*y(j);
	end
	y(i)= (L2(i, n + 1) - summe)/L2(i, i);
end

endfunction


  
