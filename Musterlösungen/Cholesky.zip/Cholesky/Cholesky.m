function [] = Cholesky()

[A,b,n] = Konfiguration2;
Fehlerbehandlung(A,b,n);
M = ErwKoeffMatrix(A,b,n);
L = CholeskyZerlegung(M,n);
disp(L);
L2 = ErwKoeffMatrix(L,b,n);
y = Vorwaertseinsetzen(L2,n);
R = ErwKoeffMatrix(transpose(L),y,n);
disp('');
disp(y);
x = Rueckwaertseinsetzen(R,n);
disp('');
disp(x);

endfunction
