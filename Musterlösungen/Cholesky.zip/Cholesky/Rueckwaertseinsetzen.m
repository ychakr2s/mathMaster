function [x] = Rueckwaertseinsetzen(R,n)

x(n)= R(n, n+1)/R(n,n);

for i = n-1 : -1 : 1
	summe = 0; 
	for j = i+1 : n
		summe = summe + (R(i,j)*x(j));
	end
	x(i)= (R(i, n + 1) - summe)/R(i, i);
end

endfunction


  
