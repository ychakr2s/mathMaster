function [] = Fehlerbehandlung(A,b,n)

% A quadratisch?
[n,m] = size(A);
if n~= m
   error('Die Matrix ist nicht quadratisch!');
end

% b Spaltenvektor der Laenge n?
[k,l] = size(b);
if k ~= n
   if l == n
      error('b ist ein Zeilenvektor!');
   end
   error('b hat die falsche Laenge!');
end

% A symmetrisch?
#if sum(sum(A == transpose(A))) < n^2
   #error('A ist nicht symmetrisch');
#end

% A positiv definit?
if(min(eig(A))) < 1.e-15
   error('A ist nicht positiv definit');
end

endfunction
