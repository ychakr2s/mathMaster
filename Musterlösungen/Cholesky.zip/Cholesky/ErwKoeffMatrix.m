function [A] = ErwKoeffMatrix(A,b,n)

for i = 1 : n
	A(i,n+1)=b(i);
end

endfunction
