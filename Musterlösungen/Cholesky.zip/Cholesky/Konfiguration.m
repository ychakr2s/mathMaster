function [A,b,n] = Konfiguration()

A = [ 1 2 1; 2 5 2; 1 2 10];
b = [1; 1; 1];
n = 3;

endfunction

